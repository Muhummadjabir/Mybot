# News Telegram Bot

This bot sends daily summarized news updates via Telegram using a free cloud like Render.com.
